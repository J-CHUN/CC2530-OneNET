﻿char ZW_DISCONNECT[] = "掉线次数";

char ZW_ERRTYPE[] = "错误类型";
