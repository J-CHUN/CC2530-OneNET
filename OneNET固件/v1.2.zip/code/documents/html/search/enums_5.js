var searchData=
[
  ['rst_5freason',['rst_reason',['../group__System__APIs.html#gaf560461b4a37405f75fd789165f6c576',1,'esp_system.h']]]
];
