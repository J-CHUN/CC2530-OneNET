var searchData=
[
  ['offer_5fend',['OFFER_END',['../group__Misc__APIs.html#gga47797d528afd74db93dd37a2c9207333ab67ba95f9dcf33d1cd600d798c76ab88',1,'esp_misc.h']]],
  ['offer_5frouter',['OFFER_ROUTER',['../group__Misc__APIs.html#gga47797d528afd74db93dd37a2c9207333ad88e6ec93eb09e1cccb8d4d039681f42',1,'esp_misc.h']]],
  ['offer_5fstart',['OFFER_START',['../group__Misc__APIs.html#gga47797d528afd74db93dd37a2c9207333a8d64153b2be4f126695bb7f6d36cff2c',1,'esp_misc.h']]]
];
