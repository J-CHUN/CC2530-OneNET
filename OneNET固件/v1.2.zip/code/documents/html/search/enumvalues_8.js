var searchData=
[
  ['reason_5fdeep_5fsleep_5fawake',['REASON_DEEP_SLEEP_AWAKE',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576acee6519d545f6be1bac3e00be8637ee7',1,'esp_system.h']]],
  ['reason_5fdefault_5frst',['REASON_DEFAULT_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576af39e71277c3bfc84b75a4a5683531565',1,'esp_system.h']]],
  ['reason_5fexception_5frst',['REASON_EXCEPTION_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a37032d096425911146ce105004cc8adb',1,'esp_system.h']]],
  ['reason_5fext_5fsys_5frst',['REASON_EXT_SYS_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a9ab5cbcccb384a176990019a8e1b2cc8',1,'esp_system.h']]],
  ['reason_5fsoft_5frestart',['REASON_SOFT_RESTART',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a6d052f0a22d1b1d060a7e017f6152559',1,'esp_system.h']]],
  ['reason_5fsoft_5fwdt_5frst',['REASON_SOFT_WDT_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a57184a4fb4d760f85fd0834566bf6e9c',1,'esp_system.h']]],
  ['reason_5fwdt_5frst',['REASON_WDT_RST',['../group__System__APIs.html#ggaf560461b4a37405f75fd789165f6c576a90f8f58c2fec687ee00f4735bf24006d',1,'esp_system.h']]]
];
