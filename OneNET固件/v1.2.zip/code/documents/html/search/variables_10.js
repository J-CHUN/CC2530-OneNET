var searchData=
[
  ['upgrade_5fflag',['upgrade_flag',['../structupgrade__server__info.html#a983ad0843b8753df3491570b65a20348',1,'upgrade_server_info']]],
  ['upgrade_5fversion',['upgrade_version',['../structupgrade__server__info.html#a54bc0d4687b1f9b5f8671bd157abd94d',1,'upgrade_server_info']]],
  ['url',['url',['../structupgrade__server__info.html#aa68fc9d50895a4a8df09b200ae030867',1,'upgrade_server_info']]]
];
