#ifndef __HCSR04_H__
#define __HCSR04_H__
#include "OnBoard.h"
#define uchar unsigned char 
#define uint unsigned int 

//��������
#define TRIG P1_1      
#define ECHO P0_6     


extern uchar RG; 
extern uchar H1; 
extern uchar L1; 
extern uchar H2; 
extern uchar L2; 
extern uchar H3; 
extern uchar L3; 
extern uint distance; 
extern uchar LoadRegBuf[4]; 
extern uchar Data[3];
//void Delay(uint n); 
void Delay_1us(uint microSecs); 
void Delay_10us(uint n); 
void Delay_1s(uint n); 
void Delay_ms(uint Time);//n ms��ʱ
void Delay_10us1(void);
//void SysClkSet32M(); 
void Init_UltrasoundRanging(void); 
void UltrasoundRanging(uchar *ulLoadBufPtr); 
__interrupt void P0_ISR(void); 
#endif